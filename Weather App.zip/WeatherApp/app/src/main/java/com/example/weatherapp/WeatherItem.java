package com.example.weatherapp;

import java.time.LocalDate;

public class WeatherItem
{
    String zipcode;
    String time;
    String location;
    String temperature;
    String img;

    public WeatherItem(String zipcode, String time, String location, String temperature, String img) {
        this.zipcode = zipcode;
        this.time = time;
        this.location = location;
        this.temperature = temperature;
        this.img = img;
    }
    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

}
