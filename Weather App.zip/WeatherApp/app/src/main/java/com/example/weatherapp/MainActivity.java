package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("STARTING","starting app");
        setContentView(R.layout.activity_main);
        AsyncThread myThread = new AsyncThread();
        myThread.execute();

    }

        public class AsyncThread extends AsyncTask<Void, Void, Void> {
            @Override
            protected Void doInBackground(Void... voids) {
                Log.d("TEST", "starting background task");
                URL weather;
                try {
                    weather = new URL(
                            "http://api.openweathermap.org/geo/1.0/zip?zip=08512,US&appid=9f52c4a9441b7b3f9f4da4a9a1252e98"
                    );
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
                //weather.put("9f52c4a9441b7b3f9f4da4a9a1252e98");
                Log.d("TEST", "starting background task");
                URLConnection connect;
                InputStream input;
                try {
                    connect = weather.openConnection();
                    input = connect.getInputStream();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                    //Log.d("TESTONE",e.toString());
                }
                Log.d("INPUT", input.toString());
                BufferedReader buffer = new BufferedReader(new InputStreamReader(input));

                //step 5
                String saver = "";
                try {
                    saver = String.valueOf(buffer.read());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                Log.d("TEST", saver);

                JSONObject info;
                try {
                    info = new JSONObject(saver);
                    //JSONArray weatherarray = info.getJSONArray("forms");
                    //square bracket : []
                    JSONObject weatherItem = info.getJSONObject("spites");
                    //sprites is the name of the "tag" for {}

                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }


                return null;

            }




        }

}